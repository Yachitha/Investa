# Investa
The Cloud based investment management platform
## About

This platform is cloud based platform with the capable of managing all the accountings happens inside a investment management company.

## Technologies used

Larvel 5.6
